/*
	Author：韦志有
	Date：2016-4-26
	Version：1.0.0
	Content：底部脚本
*/
(function(){
	/*footer start*/
	$(function(){
		var $bottomBtnScrtop = $(".footer .bottom-btn-scrtop");
		var $onlineCustomWrap = $(".footer .onlineCustomWrap");
		var $onlineBtnClose = $(".footer .onlineCustomWrap .onlineBtnClose");
		var $minOnlineCustom = $(".footer .minOnlineCustom");
		var H = $minOnlineCustom.height();
		var W = $minOnlineCustom.width();
		var H1 = $onlineCustomWrap.height();
		$minOnlineCustom.on("click",function(){
			$(this).stop(true).animate({"height":0,"width":0,"padding":0,"right":-34,"opacity":0});
			$onlineCustomWrap.fadeIn(function(){
				$(this).animate({"height":H1,"opacity":1,"right":5,});
			});
		});
		$onlineBtnClose.on("click",function(){
			$onlineCustomWrap.stop(true).animate({"height":0,"right":-74},function(){
				$(this).fadeOut();
			});
			$minOnlineCustom.stop(true).animate({"height":H,"right":0,"width":W,"padding":"10px 6px","opacity":1});
		});
		$(window).on("scroll",function(){
			if($(window).scrollTop()>500){
				$bottomBtnScrtop.css({"display":"block"}).mouseover(function(){
					$(this).css({"background-position":"0 0"});
				}).mouseout(function(){
					$(this).css({"background-position":"-38px 0"});
				}).click(function(){
					$("html,body").stop(true).animate({"scrollTop":0},800);
				});
			}else{
				$bottomBtnScrtop.css({"display":"none"});
			};
		});
	});
	/*end footer*/
})();