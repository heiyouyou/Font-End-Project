/*
	Author：韦志有
	Date：2016-4-26
	Version：1.0.0
	Content：主体导航脚本
*/
(function(){
	$(function(){
		/*menu start*/
		var $menu = $("#menu");
		var $menuLists = $("#menu .menu-list");
		var $lis = $menu.children();
		var index = 0;
		//悬浮在侧边menu-list-title触发
		$lis.mouseover(function(){
			index = $(this).index();
			$(this).css({
				backgroundColor:"#FF6537",
				paddingLeft:4
			});
			$menuLists.eq(index).show();
		}).mouseout(function(){
			$(this).css({
				backgroundColor:"",
				paddingLeft:0
			});
			$menuLists.eq(index).hide();
		});
		/*end menu*/
		/*banner-box start*/
		var $banner = $("#banner");
		var $btnUl = $("#btn-ul");
		var $bannerUl = $("#banner-ul");
		var $ears = $("#ear a");
		var $bLis = $btnUl.find("li");
		//拿到banner图的可视宽度
		var bWidth = $banner.width();
		//拿到按钮的个数
		var liLength = $bLis.length;
		//定义按钮样式变化的索引
		var bIndex = 0;
		//定义盒子$bannerUl移动的倍率
		var mIndex = 0
		//定义一个自动播放的定时器
		var timer = null;
		//定义一个时间变量
		var nowTime = 0;
		$bLis.click(function(){
			mIndex = $(this).index();
			if(new Date() - nowTime>500){
				nowTime = new Date();	
				$(this).addClass("on").siblings().removeClass("on");
				$bannerUl.animate({
					left:-bWidth*(mIndex+1)
				});
			};
		});
		//为左右耳朵绑定事件
		$ears.click(function(){
			var aIndex = $(this).index();
			//判断两次连点的时间间隔
			if(new Date() - nowTime>500){
				nowTime = new Date();	
				if(aIndex){//点击右耳朵
					mIndex++;
				}else{//点击左耳朵
					mIndex--;
				};
				fn();
			};
		});
		//封装样式变化的动画方法
		function fn(){
			bIndex = mIndex;
			if(bIndex == liLength){
				bIndex = 0;
			}else if(bIndex<0){
				bIndex = liLength-1;
			}
			$bannerUl.animate({
				left:-bWidth*(mIndex+1)
			},300,function(){
				if(mIndex == liLength){
					$(this).css({"left":-bWidth},300);
					mIndex = 0;
				}else if(mIndex<0){
					$(this).css({"left":-bWidth*liLength},300);
					mIndex = liLength-1;
				};
			});
			$bLis.eq(bIndex).addClass("on").siblings().removeClass("on");
		};
		//自动播放动画
		autoPlay();
		function autoPlay(){  
			timer = setInterval(function(){
				mIndex++;
				fn();
			},3000);
		};
		//悬浮在banner图上触发的样式
		$banner.mouseenter(function(){
			$ears.show();
			clearInterval(timer);
		}).mouseleave(function(){
			$ears.hide();
			autoPlay();
		});
		//底部小banner样式
		var $bottomLis = $(".bottom-li");
		$bottomLis.mouseover(function(){
			$(this).addClass("over-bottom-li");
		}).mouseout(function(){
			$(this).removeClass("over-bottom-li");
		});
		/*end banner-box*/
		/*right-tips start*/
		var $notice = $("#notice");
		var $noticeInfors = $("#notice .notice-infor");
		var $selectedLis = $notice.find(".selected-li");
		$selectedLis.mouseover(function(){
			var nIndex = $(this).index();
			$(this).addClass("fir-li").siblings().removeClass("fir-li");
			$noticeInfors.eq(nIndex).css("display","block").parent().siblings().find(".notice-infor").css("display","none");
		});
		/*end right-tips*/
	});
})();