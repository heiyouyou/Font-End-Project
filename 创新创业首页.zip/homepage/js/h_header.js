/*
	Author：韦志有
	Date：2016-4-26
	Version：1.0.0
	Content：头部脚本
*/
/*header start*/
(function(){
	window.onload = function(){
		var close_btn = document.getElementById("close-btn");
		var header_banner = document.getElementById("header-banner");
		var ui_dropdown = document.querySelector(".ui-dropdown");
		var ui_dropdown_menu = document.querySelector(".ui-dropdown-menu");
		var lisDom = getTag(ui_dropdown_menu,"li");
		var header_searchlabel = getId("header-searchlabel");
		var $headerTop = $(".header-top");
		var $headerBottom = $(".header-bottom");
		var $headerWrap = $("#header-wrap");
		var $hotSearch = $("#hot-search");
		var $logoWrap = $("#logo-wrap");
		/*header-banner start（点击按钮取消显示）*/
		close_btn.addEventListener("click",function(){
			header_banner.style.display = "none";
		},false);
		/*end header-banner*/
		/*search-wrap start*/
		$(window).scroll(function(){
			if($(document).scrollTop()>100){
				$headerTop.css("position","fixed");
				$headerTop.next().css("display","block");
				$headerBottom.addClass("header-bottom1").next().css("display","block");
				$headerWrap.addClass("header-wrap1");
				$hotSearch.css("display","none");
				$logoWrap.addClass("logo-wrap1");
				$headerWrap.css("height","70px");
			}else{
				$headerTop.css("position","static");
				$headerTop.next().css("display","none");
				$headerBottom.removeClass("header-bottom1").next().css("display","none");
				$headerWrap.removeClass("header-wrap1");
				$hotSearch.css("display","block");
				$logoWrap.removeClass("logo-wrap1");
				$headerWrap.css("height","85px");
			};
		});
		ui_dropdown.onmouseover = function(){
			Run(ui_dropdown_menu,{opacity:100},20,function(){
				this.style.visibility = "visible";
			});
		};
		ui_dropdown.onmouseout = function(){
			Run(ui_dropdown_menu,{opacity:0},20,function(){
				this.style.visibility = "hidden";
			});
		};
		for(var i=0;i<lisDom.length;i++){
			lisDom[i].onclick = function(){
				//innerText火狐不支持，支持textContent
				var str = this.innerText||this.textContent;
				header_searchlabel.innerHTML = str;
			};
		};
		/*end search-wrap*/
	};
})();
/*end header*/