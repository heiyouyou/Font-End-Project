/*
	Author：韦志有
	Date：2016-4-26
	Version：1.0.0
	Content：主体脚本
*/
(function(){
	/*main-box start*/
	$(function(){
		/*tab-box start*/
		var $tabBox = $(".tab-box");
		var Ttop = 0;
		//定义一个空数组放每个tab-box的offset().top
		var arr = [];
		//每个tab-box距离html文档顶部的距离初始化
		topInit();
		function topInit(){
			//将上一次的值清空
			 arr.length?arr.splice(0,$tabBox.length):arr = [];
			//拿到每个tabBox距离html文档顶部的距离
			$tabBox.each(function(i){
				Ttop = $(this).offset().top;
				//将对应的tabBox距离html文档顶部的距离放入数组
				arr.push(Ttop);
			});
			//console.log(JSON.stringify(arr));
		};
		//遍历每一个tab-box
		$tabBox.each(function(i){
			var $tabTitle = $(this).find(".tab-title");
			var $tabLis = $tabTitle.find("li");
			var $tabContent = $(this).find(".tab-content");
			var $cols = $tabTitle.find("li .cols");
			var $spacers = $tabTitle.find("li .spacer");
			var $tabCDiv = $tabContent.children();
			var TitleIndex = 0;
			$tabLis.mouseover(function(){
				topInit();
				TitleIndex = $(this).index();
				$spacers.eq(TitleIndex).css("display","block").parent().siblings().find(".spacer").css("display","none");
				$cols.eq(TitleIndex).css("background-color","transparent").parent().siblings().find(".cols").css("background-color","#ddd");
				$(this).addClass("tab-fir-li").siblings().removeClass("tab-fir-li");
				$tabCDiv.eq(TitleIndex).css("display","block").siblings().css("display","none");
			});
		});
		/*end tab-box*/
		/*index-nav start*/
		var $indexNav = $(".index-nav");
		var $sortableLis = $(".index-nav .side-nav-list .sortable");
		var $moveOn = $(".index-nav .side-nav-list .move-on");
		//获取每个li的宽度
		var sortableWidth = $sortableLis.outerWidth();
		//获取每个li的高度
		var sortableHeight = $sortableLis.outerHeight();
		//为move-on添加宽度和高度
		$moveOn.css({"width":sortableWidth,"height":sortableHeight});
		//给每隔两楼层li绑定事件
		$sortableLis.click(function(){
			//$(window).off("scroll",scrollFn);
			topInit();
			var sortableIndex = $(this).index();
			var l = $(this).position().left;
			var t = $(this).position().top;
			$(this).addClass("sortable-on").siblings().removeClass("sortable-on");
			$moveOn.stop(true).animate({"top":t,"left":l},300);
			$("html,body").stop(true).animate({"scrollTop":arr[sortableIndex]-105});
			
		});
		//window绑定scroll监听事件
		$(window).on("scroll",scrollFn);
		//封装滚动条滚动触发的效果
		function scrollFn(){
			topInit();
			//到达楼层1出现楼层滑梯
			if($(document).scrollTop()>=arr[0]-500){
				$indexNav.show();
			}else{
				$indexNav.hide();
			};
			$tabBox.each(function(i){
				if($(document).scrollTop()>=arr[i]-500){
					var l = $sortableLis.eq(i).position().left;
					var t = $sortableLis.eq(i).position().top;
					$sortableLis.eq(i).addClass("sortable-on").siblings().removeClass("sortable-on");
					$moveOn.stop(true).animate({"top":t,"left":l},100);
				}
			});
		};
		/*end index-nav*/
		/*floor-banner start*/
		//找到每一个floor-banner盒子
		var $floorBanner = $(".floor-banner")
		//遍历每个floor-banner盒子
		$floorBanner.each(function(i){
			var $floorBannerMain = $(this).find(".floor-banner-main");
			var $floorBannerUlS = $floorBannerMain.find(".floor-banner-ul");
			var fBannerlength = $floorBannerUlS.length;
			var $fBannerBtn = $(this).find(".f-banner-btn");
			var $fBannerBtnDiv = $fBannerBtn.find("div");
			//拿到当前floorBanner盒子的高度
			var floorBannerHeight = $(this).height();
			//移动倍率
			var moveIndex = 0;
			var floorTime = 0; 
			var floorBannerTimer = null;
			//点击左右耳朵
			$fBannerBtnDiv.click(function(){
				var DivIndex = $(this).index();
				if(new Date() - floorTime>500){
					floorTime = new Date();
					if(DivIndex){
						moveIndex--;
					}else{
						moveIndex++;
					};
					moveUp();
				};
			});
			//移动动画
			function moveUp(){
				$floorBannerMain.animate({"margin-top":-(moveIndex+1)*floorBannerHeight},function(){
					if(moveIndex<0){
						//回到最后一列图片
						moveIndex = fBannerlength-2;
						$(this).css("margin-top",-moveIndex*floorBannerHeight);
						//第一列图片过渡索引
						moveIndex = fBannerlength-3;
					}else if(moveIndex==fBannerlength-2){
						$(this).css("margin-top",-floorBannerHeight);
						//最后一列图片过渡索引
						moveIndex = 0;
					};
				});
			};
			//自动播放
			floorBannerAutoPlay();
			function floorBannerAutoPlay(){
				floorBannerTimer = setInterval(function(){
					moveIndex--;
					moveUp();
				},4000);
			};
			$(this).mouseover(function(){
				clearInterval(floorBannerTimer);
				$fBannerBtnDiv.show();
			}).mouseout(function(){
				floorBannerAutoPlay();
				$fBannerBtnDiv.hide();
			});
		});
		/*end floor-banner*/
	});
	/*end main-box*/
})();