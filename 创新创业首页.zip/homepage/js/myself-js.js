/*
	Author：韦志有
	Date：2016-4-26
	Version：1.0.0
	Content：自定义类库
*/
//封装获取样式的方法
function getStyle(obj,value){
	/*return obj.currentStyle?obj.currentStyle[value]:getComputedStyle(obj)[value];*/
	//value = value.trim();//这种方法只能将字符串的前后空格去掉不能将中间的空格去掉
	var values = value.split(" ");//split与join结合使用就可以将中间空格去掉
	var value = values.join("");
	if(obj.currentStyle){//这里表示哪个浏览器支持就往下执行if语句里的代码，要不然就执行else里的语句
		return obj.currentStyle[value];//注意这里不能点只能用[]包裹变量，且必须传入的是字符串
	}else{
		return getComputedStyle(obj)[value];
	}
};
//封装通过元素名称获取元素的方法
function getTag(obj,ele){
	return obj.getElementsByTagName(ele);
};
//正则封装兼容ie678的获取某一类样式的元素的写法
function getClass(cN,obj){
	obj = obj||document;
	if(obj.getElementsByClassName){
		return obj.getElementsByClassName(cN);
	}else{
		var arr = [];
		/*var reg = /\bcN\b/;这样写不对！！!*/
		var reg = new RegExp("\\b"+cN+"\\b");
		var allE =  obj.getElementsByTagName("*");
		for(var i=0;i<allE.length;i++){
			if(reg.test(allE[i].className)){
				arr.push(allE[i]);
			}
		}
		return arr;
	};
};
//封装获取id的方法
function getId(id){
	return document.getElementById(id);
};
//封装siblings方法
function siblings(obj,callback){
	var pDoms = obj.parentNode.children;
	var arr = [].slice.call(pDoms);
	arr.filter(function(others){
		if(others!=obj){
			callback.call(others);
		}
	})
};
//封装获取（id和className）元素和函数执行的方法
function $All(param,obj){//jQuery中的传入id和className形式：$("#id"),$(".className")
	obj = obj||document;
	var typeP = typeof param;//将传入的param进行类型判断
	if(typeP == "function"){//判断传入的param是函数还是字符串
		window.onload = param;
	}else if(typeP.toUpperCase() == "STRING"){//调用toUpperCase()是为了解决不同浏览器因为对字符串string的大小写判断不一
		var firStr = param.charAt();//charAt()不传入任何参数，默认是返回下标为0的字符,这里的意思是用来判断传入id还是className
		if(firStr == "#"){
			param = param.substring(1,param.length);//从param下标1截取后面部分
			return obj.getElementById(param);//返回传入的id给函数$All()
		}else if(firStr == "."){
			param = param.substring(1,param.length);
			//这个方法支持ie9+和其他浏览器
			if(obj.getElementsByClassName){//只有ie9+和其他浏览器支持才会执行if语句里的东西
				return obj.getElementsByClassName(param);//获取obj对象下类名为传入的param的元素而组成的数组，然后返回数组给函数$
			}
			var all = obj.getElementsByTagName("*");
			var arrClass = [];//用一个空数组来接收具有类样式box的元素
			for(var i=0;i<all.length;i++){
				var arr = all[i].className.split(" ");//通过split()以空格号来划分具有多个类样式的元素的className切割成数组用arr来存，注意className都是字符串！！！
				for(var j=0;j<arr.length;j++){//循环嵌套循环，每个循环的边界变量最好不要相同，易引起混乱
					if(arr[j] == param){
						arrClass.push(all[i]);//将具有box样式的元素存入原来的空数组arrClass
					};
				};
			};
			return arrClass;//返回一个传入类样式(类名)为param的数组
		};
	};
};
//封装监听事件的绑定
function jsBind(obj,eName,fn){
	if(obj.addEventListener){
		//obj.addEventListener(eName,fn,false);//如果只是传入一个函数名fn,this就指代当前调用函数的obj
		obj.addEventListener(eName,function(){
			fn.call(obj);//如果函数是这样执行时利用call将this重新指向obj,要不然就是undefined
		},false);
	}else{
		//obj.attachEvent("on"+eName,fn);//如果只传入函数名fn，this指代不明也是会报错的
		obj.attachEvent("on"+eName,function(){
			fn.call(obj);//如果函数是这样执行时利用call将this重新指向obj,要不然就是报错
		});
	}
};
//封装具有过渡与延迟效果的动画方法
function Run(obj,json,times,callback){
	//清除上一次结束动画
	clearInterval(obj.timer);
	//动态给对象绑定一个定时器
	obj.timer = setInterval(function(){
		//定义一个开着的锁，用来进行判断是否清除定时器
		var mark = true;
		//先将json里的值全拿出来才会跳出循环执行下一次定时器
		for(var attr in json){
			//这里不要放在定时器外面，要每次更新pos的值,并且判断对象元素有没有属性attr，没有就pos赋值0
			if(attr == "opacity"){
				//乘以100变成百分比
				var pos = getStyle(obj,attr)*100;
			}else{
				//获取样式其它属性（具有px的属性，若没有则用0代替）
				var pos = parseInt(getStyle(obj,attr))||0;
			}
			//拿到json对象里的目标值
			var target = json[attr];
			//将速度进行动态减速
			var speed = (target-pos)*0.4;
			/*//当target大于pos时
			if(speed>0){
				speed = Math.ceil(speed);
			}
			//当target小于pos时
			if(speed<0){
				speed = Math.floor(speed);
			}*/
			speed = speed>0?Math.ceil(speed):Math.floor(speed);
			//当pos达不到目标位置时继续改变属性值
			if(pos!=target){
				//每次从上次的位置改变
				if(attr == "opacity"){
					obj.style[attr] = (pos+speed)/100;
					console.log(speed+"==="+pos+"==="+(pos+speed));
				}else{
					obj.style[attr] = pos+speed+"px";
				}
				//只要传入的attr没有达到目标值，mark始终为false
				mark = false;
			}					
		}
		//如果为真进行清除定时器
		if(mark){
			clearInterval(obj.timer);
			//当上一次动画执行完回调函数就执行
			if(callback)callback.call(obj);
		}
	},times);
};
//封装匀速移动的方法
function run1(obj,attr,target,speed,times,callback){
	clearInterval(obj.timer2);
	obj.timer2 = setInterval(function(){
		//防止对象元素没有传入的attr样式所以取或后面的0
		var pos = parseInt(getStyle(obj,attr))||0;
		console.log(pos);
		if(pos==target){
			clearInterval(obj.timer2);
			if(callback){
				callback.call(obj);
			}
		}else{
			obj.style[attr] = pos+speed+"px";
			console.log(pos+speed+"px");
		}
		/*停在对象上时停止移动*/
		/*obj.addEventListener("mouseover",function(ev){
			var e = ev||event;
			clearInterval(this.timer2);
			//判断目标对象是否是span
			var span = e.target.tagName;
			if(span.toLowerCase() == "span"){
				//为obj中span元素添加内容
				this.querySelector(span).innerHTML = "点击即可查看当前系统时间^-^";
			};
		},false)*/
		tg(obj).on("mouseover","span",function(){
			clearInterval(obj.timer2);
			this.innerHTML = "点击即可查看当前系统时间^-^";
		});
		/*离开对象时出发移动*/
		obj.onmouseout = function(){
			run1(obj,attr,target,speed,times,callback);
		};
	},times);
};
//封装当前系统时间的方法
function currentTime(obj){
	setInterval(function(){
		var timers = new Date();
		var years = timers.getFullYear();
		var months = timers.getMonth()+1;
		var date = timers.getDate();
		var day = timers.getDay();
		var hour = timers.getHours();
		var minutes = timers.getMinutes();
		var seconds = timers.getSeconds();
		switch (day){
			case 0:
			day = "星期天";
			break;
			case 1:
			day = "星期一";
			break;
			case 2:
			day = "星期二";
			break;
			case 3:
			day = "星期三";
			break;
			case 4:
			day = "星期四";
			break;
			case 5:
			day = "星期五";
			break;
			case 6:
			day = "星期六";
			break;
		};
		function two(key){
			key<10?key = "0"+key:key = key;
			return key;
		}
		obj.innerText = years+"年"+months+"月"+date+"日"+day+two(hour)+":"+two(minutes)+":"+two(seconds);
	},1000);
};
//封装倒计时方法
function countDown(y,m,d,time){
	var timeDom = document.getElementById("time");
	var startTime = new Date();//注意这里不能放在time方法外！！！
	var endTime = new Date(y,m-1,d);//传入要进行倒计时的时间
	var ms = endTime.getTime() - startTime.getTime();//先拿到传入的时间与当前时间的差值 单位为毫秒
	var sec = ms/1000;//然后将毫秒数转成秒除1000
	var day = Math.floor(sec/60/60/24);//得到剩余多少整数天
	var hour = Math.floor(sec/60/60%24);//将取余得到的小时赋值给hour
	var min = Math.floor(sec/60%60);//将取余得到的分钟赋值给min
	var ss = Math.floor(sec%60);//将取余得到的秒数赋值给ss
	function two(n){//将分秒小于10时变成两位数
		if(n<10){
			n = "0"+n;
		}
		return n;
	};
	var text = "距离"+endTime.getFullYear()+"年"+(endTime.getMonth()+1)+"月"+endTime.getDate()+"日<span style='color:red;'>高考还有"+day+"日"+hour+"小时"+two(min)+"分钟"+two(ss)+"秒</span>";	
	timeDom.innerHTML = text;
};
//封装事件委托的方法
var tg = function(obj){
	var dom = obj;
	return {
		on:function(eventType,targetElement,callback){
			dom.addEventListener(eventType,function(ev){
				//获取目标对象的标签名称
				var e = ev||event;
				//兼容ie678的写法
				var t = e.target||e.srcElement;
				//如果目标对象的标签名与传递过来的标签名一致
				if(t.tagName.toLowerCase() == targetElement){
					//第一个参数表示改变回调函数this的指针，将其指向传递过来的目标元素，第二个参数表示事件类型
					callback.call(t,e);
				}
			},false);
		}
	}
};
//封装获取和设置属性的方法
function attr(obj,key,value){
	if(value){
		obj.setAttribute(key,value);
	}else{
		return obj.getAttribute(key);
	};
};